<?php
    $con = mysqli_connect("localhost", "root", "", "kod");
    if(!$con){
        echo"connection error";
    }
?>