<?php
require"connect.php";
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $fName = $_POST['fName'];
    $lName = $_POST['lName'];
    $email = $_POST['email'];
    
    if(!empty($fName) && !empty($lName) && !empty($email)){
        $sql = mysqli_query($con, "INSERT INTO `log`(`f_name`, `l_name`, `email`) VALUES('$fName', '$lName', '$email')");
        if($sql == true){
            $key = "success";
            $message = "Congratulation";
        }else{
            $key = "error";
            $message = "could not creat your account";
        }
    }else{
        $key = "failed";
        $message = "All Field required";
    }
    echo json_encode(array("key"=>$key, "message"=>$message));
}

?>